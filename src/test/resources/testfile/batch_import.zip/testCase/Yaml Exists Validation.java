import java.util.Map;

/**
 * the method name,input parameter and return value type is fixed, please write function in this
 * method. if test case passed,please return "success", otherwise, return the fail reason
 */
public class DangerPortScanning {

    /**
     * 
     * @param csarFilePath app package path
     * @param context context info
     * @return success or failed reason
     */
    public String execute(String filePath, Map<String, String> context) {
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
        }
        return "success";
    }
}
